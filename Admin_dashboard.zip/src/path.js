export const ApiURL = "http://localhost:8000/api";
export const ImageApiURL = "http://localhost:8000";
