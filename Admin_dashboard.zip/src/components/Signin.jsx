
import { FcGoogle } from "react-icons/fc";
import React from 'react';

const Signin = () => {
  return (
   <div>hello dear yogesh</div>
  );
}

export default Signin;