import React from "react";

function TermsConditions() {
  return <div>Terms&conditions</div>;
}

export default TermsConditions;
